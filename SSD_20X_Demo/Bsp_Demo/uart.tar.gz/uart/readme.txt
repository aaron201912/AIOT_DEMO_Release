
使用方式：
arm-linux-gnueabihf-gcc uart.c -o main

应用程序将接收的数据，发送到对方。