#ifndef __MYPNG_H__
#define __MYPNG_H__
#include <stdio.h>
#include "bmp.h"


int load_PNG_file(FILE *fp, BITMAP *fb);

#endif
