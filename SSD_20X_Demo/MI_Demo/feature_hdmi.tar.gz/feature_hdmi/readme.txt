使用方式：
将此目录放置到project 同级别目录下. 
ALKAID_PATH先指向sdk的路径
declare -x ALKAID_PATH=~/sdk/TAKOYAKI_DLS01V011/sourcecode/bootlogo_test
执行make 
./feature_hdmi default_hdmi_ut.ini 

